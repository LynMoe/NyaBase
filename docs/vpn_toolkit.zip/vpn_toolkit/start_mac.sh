./v2ray_mac run -c config.json
